from setuptools import setup


setup(name='calculation',
    version='0.2',
    description='calculation avg service demo package',
    url='#',
    author='Soroush',
    author_email='soroosh1381amir@gmail.com',
    license='MIT',
    packages=['calculation'],
    # install_requires=['requests'],
    zip_safe=False
)