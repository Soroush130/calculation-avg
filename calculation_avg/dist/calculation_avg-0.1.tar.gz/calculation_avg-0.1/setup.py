from setuptools import setup


setup(name='calculation_avg',
    version='0.1',
    description='calculation avg service demo package',
    url='#',
    author='Soroush',
    author_email='soroosh1381amir@gmail.com',
    license='MIT',
    packages=['calculation'],
    # install_requires=['requests'],
    zip_safe=False
)